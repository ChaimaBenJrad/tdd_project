package com.example.myapp.tpTdd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TicTacToeSave implements GererBaseDeDonnees{
	private Connection connection;
	private GererBaseDeDonnees bd;
	public TicTacToeSave(GererBaseDeDonnees bd) {
		this.bd=bd;
	}
	@Override
	public Connection connect() {
		return null;
		// TODO Auto-generated method stub
		
	}
	@Override
	public void verrify() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean create() {
		return false;
		// TODO Auto-generated method stub
		
	}
	@Override
	public void drop() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void save(Data d) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean reinitialiserJeu() {
		// TODO Auto-generated method stub
		return false;
	}
	
}