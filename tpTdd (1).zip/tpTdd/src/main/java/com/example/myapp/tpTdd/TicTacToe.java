package com.example.myapp.tpTdd;
public class TicTacToe{
	private char[][] grille;
	private char joueurActuel;
	
	public TicTacToe() {
		grille = new char[3][3];
		joueurActuel='X';
	}
	
	public void placerPion(int x, int y) {
		if(x<0 || x>2 || y<0 || y>2) {
			throw new RuntimeException("La position du pion est incorrecte");}
		if(grille[x][y]!=0) {
			throw new RuntimeException("La case indiquée est occupée");
		}
		grille[x][y]=joueurActuel;
	}
	
	public boolean estOccupee(int ligne, int colonne) {
		if (ligne < 0 || ligne >= 3 || colonne < 0 || colonne >= 3) {
			throw new IllegalArgumentException("Coordonnées hors limites");
		}
		return grille[ligne][colonne]=='X' || grille[ligne][colonne]=='O';
	}
	public void placerMouv(int ligne, int colonne, char symbole) {
	    if (ligne < 0 || ligne >= 3 || colonne < 0 || colonne >= 3) {
	        throw new IllegalArgumentException("Numéros de ligne ou de colonne incorrectes");
	    }
	    if (estOccupee(ligne, colonne)) {
	        throw new RuntimeException("La case est déjà occupée");
	    }
	    grille[ligne][colonne] = symbole;
	}
	public void tourSuiv() {
		if(joueurActuel=='X') {
			joueurActuel='O';
		}
		else {
			joueurActuel='X';
		}
	}
	
	public boolean gagnerVerif(){
		if(grille[0][0]==joueurActuel && grille[1][1]==joueurActuel && grille[0][0]==joueurActuel)
			return true;
		if(grille[0][2]==joueurActuel && grille[1][1]==joueurActuel && grille[2][0]==joueurActuel)
			return true;
		for(int i=0; i<3; i++) {
			if(grille[i][0]==joueurActuel && grille[i][1]==joueurActuel && grille[i][2]==joueurActuel)
				return true;
			if(grille[0][i]==joueurActuel && grille[1][i]==joueurActuel && grille[2][i]==joueurActuel)
				return true;
		}
		return false;
	}
	
	public boolean matchFiniVerif() {
		for(int i=0; i<3; i++){
			for(int j=0; j<3; j++) {
				if(grille[i][j]==0) {
					return false;
				}
			}
		}
		return true;
	}
	
	public char getJoueurActuel(){
		return joueurActuel;
	}
	
	public char[][] getGrille(){
		return grille;
	}
	
	public void placerMouvement(int x, int y, char joueur) {
        if (x < 0 || x >= 3 || y < 0 || y >= 3) {
            throw new IllegalArgumentException("Coordonnées dehors des limites");
        }
        if (estOccupee(x, y)) {
            throw new RuntimeException("Case déjà occupée");
        }
        grille[x][y] = joueur;
    }
}