package com.example.myapp.tpTdd;

public class Data{
	private int tour;
	private int x;
	private int y;
	private char joueur;
	
	public Data(int tour, int x, int y, char joueur) {
		this.tour=tour;
		this.x=x;
		this.y=y;
		this.joueur=joueur;
	}
	
	public int getTour() {
		return tour;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getJoueur() {
		return joueur;
	}
	public String toString() {
		return String.format("Turn: %d; X: %d; Y: %d; Player: %s", tour,
		x, y, joueur);
		}
}