package com.example.myapp.tpTdd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface GererBaseDeDonnees{
	Connection connect();
	void verrify();
	boolean create();
	void drop();
	void save(Data d);
	public static final Connection connection = null;
	public default boolean enregistrerMouvement(int x, int y, char joueur) {
        String query = "INSERT INTO mouvements (x, y, joueur) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, x);
            preparedStatement.setInt(2, y);
            preparedStatement.setString(3, String.valueOf(joueur));
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
	boolean reinitialiserJeu();
}