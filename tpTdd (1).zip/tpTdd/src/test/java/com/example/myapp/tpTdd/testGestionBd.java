package com.example.myapp.tpTdd;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class testGestionBd {

    private GererBaseDeDonnees gestionBd;
    private Connection mockConnection;
    private Statement mockStatement;
    private ResultSet mockResultSet;

    @BeforeEach
    public void init() throws SQLException {
        mockConnection = mock(Connection.class);
        mockStatement = mock(Statement.class);
        mockResultSet = mock(ResultSet.class);
        when(DriverManager.getConnection(anyString(), anyString(), anyString())).thenReturn(mockConnection);
        when(mockConnection.createStatement()).thenReturn(mockStatement);
    }

    @Test
    public void testSeConnecterALaBaseDeDonneesExiste() throws SQLException {
        when(mockStatement.executeQuery("SHOW DATABASES LIKE 'tic_tac_toe'")).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        Connection conn = gestionBd.connect();
        assertNotNull(conn);
        verify(mockStatement).executeQuery("SHOW DATABASES LIKE 'tic_tac_toe'");
    }

    @Test
    public void testSeConnecterALaBaseDeDonneesQuiNExistePas() throws SQLException {
        when(mockStatement.executeQuery("SHOW DATABASES LIKE 'tic_tac_toe'")).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(false);
        Connection conn = gestionBd.connect();
        assertNull(conn);
        verify(mockStatement).executeQuery("SHOW DATABASES LIKE 'tic_tac_toe'");
    }
    
    @Test
    public void testCreationBaseDeDonnees() throws SQLException {
        boolean result = gestionBd.create();
        assertTrue(result);
        verify(mockStatement).executeUpdate("CREATE DATABASE IF NOT EXISTS tic_tac_toe");
    }
    
    @Test
    public void testEnregistrerMouvementSucces() throws SQLException {
        when(gestionBd.connect()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(anyString())).thenReturn(mock(PreparedStatement.class));
        boolean result = gestionBd.enregistrerMouvement(1, 1, 'X');
        assertTrue(result);
        verify(mockConnection).prepareStatement("INSERT INTO mouvements (x, y, joueur) VALUES (?, ?, ?)");
    }

    @Test
    public void testEnregistrerMouvementEchec() throws SQLException {
        when(gestionBd.connect()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(anyString())).thenThrow(SQLException.class);
        boolean resultat = gestionBd.enregistrerMouvement(1, 1, 'X');
        assertFalse(resultat);
    }

    @Test
    public void testReinitialiserJeuSucces() throws SQLException {
        when(gestionBd.connect()).thenReturn(mockConnection);
        when(mockConnection.createStatement()).thenReturn(mockStatement);
        boolean resultat = gestionBd.reinitialiserJeu();
        assertTrue(resultat);
        verify(mockStatement).executeUpdate("DELETE FROM mouvements");
    }

}
