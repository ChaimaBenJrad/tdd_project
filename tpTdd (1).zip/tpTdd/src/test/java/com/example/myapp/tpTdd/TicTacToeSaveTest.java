package com.example.myapp.tpTdd;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;

public class TicTacToeSaveTest{
	@Test
	public void testEnregistrerMouvement() {
		GererBaseDeDonnees mockBD = mock(GererBaseDeDonnees.class);
		doNothing().when(mockBD).connect();
		doNothing().when(mockBD).save(any(Data.class));
		TicTacToeSave enregJeu = new TicTacToeSave(mockBD);
		boolean resultat = enregJeu.enregistrerMouvement(0, 0, 'X');
		verify(mockBD).save(any(Data.class));
		assertTrue(resultat);
	}
}
