package com.example.myapp.tpTdd;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.*;

import java.sql.SQLException;

public class TicTacToeTest{
	private TicTacToe jeu;
	
	@Before
	public void init() {
		jeu = new TicTacToe();
	}
	
	@Test(expected = RuntimeException.class)
	public void testPlacerPionHorsCoordonneesX() {
		jeu.placerPion(3, 0);
	}
	
	@Test(expected = RuntimeException.class)
	public void testPlacerPionHorsCoordonneesY() {
		jeu.placerPion(0, 3);
	}

	@Test
	public void testPlacePionOccupee() {
		TicTacToe mockJeu = mock(TicTacToe.class);
		when(mockJeu.estOccupee(0, 0)).thenReturn(true);
        assertThrows(RuntimeException.class, () -> mockJeu.placerMouvement(0, 0, 'X'));
	}
	
	@Test
	public void testPremierTour(){
		assertEquals('X', jeu.getJoueurActuel());
	}
	
	@Test
	public void testTourSuivantDeXAO(){
		jeu.tourSuiv();
		assertEquals('O', jeu.getJoueurActuel());
	}
	
	@Test
	public void testTourSuivantDeOAX(){
		jeu.tourSuiv();
		jeu.tourSuiv();
		assertEquals('X', jeu.getJoueurActuel());
	}

	@Test
	public void testGagnerHorizontal() {
		jeu.placerPion(0, 0);
		jeu.tourSuiv();
		jeu.placerPion(1, 0);
		jeu.tourSuiv();
		jeu.placerPion(0, 1);
		jeu.tourSuiv();
		jeu.placerPion(1, 1);
		jeu.tourSuiv();
		jeu.placerPion(0, 2);
		assertTrue(jeu.gagnerVerif());
	}
	
	@Test
	public void testGagnerVertical() {
		jeu.placerPion(0, 0);
		jeu.tourSuiv();
		jeu.placerPion(0, 1);
		jeu.tourSuiv();
		jeu.placerPion(1, 0);
		jeu.tourSuiv();
		jeu.placerPion(1, 1);
		jeu.tourSuiv();
		jeu.placerPion(2, 0);
		assertTrue(jeu.gagnerVerif());
	}
	
	@Test
	public void testGagnerDiagonal() {
		jeu.placerPion(0, 0);
		jeu.tourSuiv();
		jeu.placerPion(1, 1);
		jeu.tourSuiv();
		jeu.placerPion(0, 1);
		jeu.tourSuiv();
		jeu.placerPion(2, 2);
		assertTrue(jeu.gagnerVerif());
	}
	
	@Test
	public void testMatchFini(){
		jeu.placerPion(2, 0);
		jeu.tourSuiv();
		jeu.placerPion(2, 1);
		jeu.tourSuiv();
		jeu.placerPion(2, 2);
		jeu.tourSuiv();
		jeu.placerPion(0, 0);
		jeu.tourSuiv();
		jeu.placerPion(0, 1);
		jeu.tourSuiv();
		jeu.placerPion(0, 0);
		jeu.tourSuiv();
		jeu.placerPion(1, 2);
		jeu.tourSuiv();
		jeu.placerPion(1, 0);
		jeu.tourSuiv();
		jeu.placerPion(1, 1);
		assertTrue(jeu.matchFiniVerif());
	}
	
	@Test
	public void testConnexionBaseDeDonnees() {
		GererBaseDeDonnees mockBD = mock(GererBaseDeDonnees.class);
		TicTacToeSave save = new TicTacToeSave(mockBD);
		save.create();
		save.connect();
		save.verrify();
	}

}